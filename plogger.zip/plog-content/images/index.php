<?php
// Ignorance is bliss
?>