<?php echo plogger_generate_seo_meta_tags(); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo THEME_URL ?>gallery.css" media="screen" />
	<script type="text/javascript" src="<?php echo THEME_URL ?>dynamics.js"></script>
	<!--[if lte IE 6]>
	<link rel="stylesheet" href="<?php echo THEME_URL ?>explorer.css" type="text/css" media="screen" />
	<![endif]-->
